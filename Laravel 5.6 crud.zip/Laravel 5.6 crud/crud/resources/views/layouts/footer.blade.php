<footer class="margin-tb-3">
    <div class="row">
        <div class="col-lg-12">
            <p>Copyright &copy; w3programmers 2017</p>
        </div>
    </div>
</footer>