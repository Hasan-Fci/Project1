
@extends('layouts.master')
@section('title', 'W3Programmers Home Page')
@section('content')
<h1>Welcome! Your can add your contact in this app</h1>
@stop