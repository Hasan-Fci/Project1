<p>Posted by <span class="glyphicon glyphicon-user"></span> <a href="#">Masud Alam</a> on <span class="glyphicon glyphicon-time"></span> 27 December 2018 10:00 am</p>
@extends('layouts.master')
@section('title', 'W3Programmers Contact Page')
@section('content')
<h2>This is my Contact page</h2>
@stop