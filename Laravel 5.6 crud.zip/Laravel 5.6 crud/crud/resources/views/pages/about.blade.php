
@extends('layouts.master')
@section('title', 'W3Programmers About Page')
@section('content')
<h2>This is my About page</h2>
@stop