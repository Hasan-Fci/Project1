@extends('layouts.layout')
@section('content')

    <h1>Welcome! You can add your contact list in this app</h1>

@endsection