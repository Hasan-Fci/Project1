<?php $__env->startSection('content'); ?>
<div class="box span6">
	<div class="box-header">
		<h2><i class="halflings-icon align-justify"></i><span class="break"></span>Striped Table</h2>
		<div class="box-icon">
			<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
			<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
			<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
		</div>
	</div>
	<p class="alert-success" style="font-size: 20px;"><?php
$message = Session::get('message');
if ($message) {
	echo $message;
	Session::put('message', null);
}
?>
	</p>
	<div class="box-content">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>ID</th>
					<th>Contact Name</th>
					<th>Number</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $hasan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($val->id); ?></td>
					<td class="center"><?php echo e($val->contact_name); ?></td>
					<td class="center"><?php echo e($val->contact_number); ?></td>
					<td class="center">
						<a href="<?php echo e(URL::to('/edit_contact/'.$val->id)); ?>" class="btn btn-primary">Edit</a>
						<a onclick="return confirm('Are You Sure To Delete')" href="<?php echo e(URL::to('/delete_contact/'.$val->id)); ?>" class="btn btn-danger" id="delete">Delete</a>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>
	</div>
	</div><!--/span-->
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>