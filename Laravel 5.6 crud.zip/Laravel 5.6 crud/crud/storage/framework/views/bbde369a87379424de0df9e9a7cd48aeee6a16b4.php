<?php $__env->startSection('content'); ?>
<div class="box-content">
	<p><?php 
	$message=Session::get('message');
	if($message)
	{
		echo $message;
		Session::put('message',null);
	}
	 ?>
	</p>
	
	<form class="form-horizontal" method="post" action="<?php echo e(URL('/update_contact',$all_contact_info->id)); ?>">
		<?php echo e(csrf_field()); ?>  <!-- form ta secured korar jonno  -->
		<fieldset>
			<div class="control-group">
				<label class="control-label" for="focusedInput">Contact name</label>
				<div class="controls">
					<input class="input-xlarge focused" id="focusedInput" type="text" name="contact_name" value="<?php echo e($all_contact_info->contact_name); ?>">
				</div>
			</div>

			<div class="control-group">
				<label class="control-label" for="focusedInput">Contact number</label>
				<div class="controls">
					<input class="input-xlarge focused" id="focusedInput" type="number" name="contact_number" value="<?php echo e($all_contact_info->contact_number); ?>">
				</div>
			</div>
			
			
			<div class="form-actions">
				<button type="submit" class="btn btn-primary">Update Contact</button>
			</div>
		</fieldset>
	</form>
	
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>