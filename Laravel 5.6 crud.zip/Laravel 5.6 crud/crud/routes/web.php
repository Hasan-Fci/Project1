<?php

Route::get('/', function () {
	return view('layouts.master');
});

Route::get('/addcontact', 'MyController@addcontact');
Route::post('/save_contact', 'MyController@save_contact');
Route::get('/allcontact', 'MyController@allcontact');
Route::get('/edit_contact/{id}', 'MyController@edit_contact');
Route::post('/update_contact/{id}', 'MyController@update_contact');
Route::get('/allinfo', 'MyController@allcontact');
Route::get('/delete_contact/{id}', 'MyController@delete_contact');
